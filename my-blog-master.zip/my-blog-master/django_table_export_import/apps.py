from django.apps import AppConfig


class DjangoTableExportImportConfig(AppConfig):
    name = 'django_table_export_import'
